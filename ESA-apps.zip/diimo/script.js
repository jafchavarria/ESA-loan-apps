async function loadContent(page) {
  const content = document.getElementById("content");

  try {
    const response = await fetch(page);

    if (!response.ok) {
      throw new Error("Page not found");
    }

    const html = await response.text();

    content.innerHTML = html;

    content.scrollTo({
      top: 0,
      behavior: "smooth",
    });
  } catch (error) {
    content.innerHTML = `
      <h2>Error</h2>

      <p>
        The requested content could not be loaded.
      </p>
    `;

    console.error(error);
  }
}
